﻿namespace Riddles.Models
{
    // Models/Riddle.cs
    public class Riddle
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }

}
